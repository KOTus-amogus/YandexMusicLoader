plugins {
    id("com.android.application") version "8.6.1" apply false
    id("com.chaquo.python") version "16.1.0" apply false
}
