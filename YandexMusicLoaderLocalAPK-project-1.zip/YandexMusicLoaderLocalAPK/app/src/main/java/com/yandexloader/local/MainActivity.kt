package com.yandexloader.local

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private var serverStarted = false
    private val storageRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLoading()
        requestStoragePermissionIfNeeded()
        startLocalPythonServer()
    }

    private fun showLoading() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(18, 18, 18))
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "🎵 Yandex Music Loader"
            textSize = 22f
            setTextColor(Color.rgb(255, 179, 0))
            gravity = Gravity.CENTER
        }
        progress = ProgressBar(this)
        val subtitle = TextView(this).apply {
            text = "Запускаю локальный Python-сервер…"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        layout.addView(title)
        layout.addView(progress)
        layout.addView(subtitle)
        setContentView(layout)
    }

    private fun requestStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 32) {
            val missing = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), storageRequest)
        }
    }

    private fun startLocalPythonServer() {
        Thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val py = Python.getInstance()
                if (!serverStarted) {
                    serverStarted = true
                    py.getModule("main").callAttr("start_server")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Не удалось запустить Python: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()

        Thread {
            var ready = false
            repeat(40) {
                if (!ready) {
                    try {
                        val conn = java.net.URL("http://127.0.0.1:8550/").openConnection() as java.net.HttpURLConnection
                        conn.connectTimeout = 400
                        conn.readTimeout = 400
                        conn.connect()
                        ready = conn.responseCode == 200
                        conn.disconnect()
                    } catch (_: Exception) { Thread.sleep(350) }
                }
            }
            runOnUiThread {
                if (ready) showWebView() else Toast.makeText(this, "Сервер пока не ответил. Закрой и открой приложение ещё раз.", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun showWebView() {
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.loadUrl("http://127.0.0.1:8550/")
        setContentView(webView)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
