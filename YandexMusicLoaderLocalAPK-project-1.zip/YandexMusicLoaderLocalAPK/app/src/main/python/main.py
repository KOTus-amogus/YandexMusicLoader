import os, re, requests
from hashlib import md5
from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Yandex Music Loader 3000</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#121212; color:#e0e0e0; padding:20px; font-family: sans-serif; }
        .card { background:#1e1e1e; border:1px solid #333; color:#fff; margin-bottom:15px; }
        .nav-link { color:#aaa; } .nav-link.active { background:#ffb300 !important; color:#000 !important; font-weight:bold; }
        #log { background:#000; height:280px; overflow-y:auto; font-family:monospace; padding:10px; border:1px solid #333; border-radius: 5px; }
    </style>
</head>
<body>
    <h3 class="text-center text-warning mb-4">🎵 Yandex Music Loader 3000</h3>
    <div class="card p-3">
        <label class="text-warning small mb-1">OAuth Токен:</label>
        <input type="password" id="tok" class="form-control bg-dark text-white mb-2" placeholder="Вставь OAuth-токен">
        <label class="text-warning small mb-1">Путь сохранения треков:</label>
        <input type="text" id="pth" class="form-control bg-dark text-white" value="/storage/emulated/0/Download/YandexMusic">
    </div>
    <ul class="nav nav-pills justify-content-center mb-3">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#m1">Медиатека</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#m2">По ссылке</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#m3">Поиск</button></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade show active text-center" id="m1"><button class="btn btn-warning w-100" onclick="go('sync_likes')">🔄 Синхронизировать «Мне нравится»</button></div>
        <div class="tab-pane fade" id="m2"><div class="input-group"><input type="text" id="url" class="form-control bg-dark text-white" placeholder="https://music.yandex.ru/..."><button class="btn btn-warning" onclick="go('by_url')">Скачать</button></div></div>
        <div class="tab-pane fade" id="m3"><div class="input-group mb-2"><input type="text" id="sch" class="form-control bg-dark text-white" placeholder="Название трека..."><button class="btn btn-warning" onclick="find()">Искать</button></div><div id="res"></div></div>
    </div>
    <h6 class="mt-3 text-warning">Консоль / Лог выполнения:</h6>
    <div id="log"><div style="color:#aaa">[Система] Панель готова. Введи OAuth-токен.</div></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function addLog(m,c='white'){const e=document.getElementById('log');e.innerHTML+=`<div style="color:${c}">${m}</div>`;e.scrollTop=e.scrollHeight;}
        async function go(t){addLog(`[*] Отправка запроса на ${t}...`,'#00f0ff');try{const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:t,token:document.getElementById('tok').value,path:document.getElementById('pth').value,url:document.getElementById('url').value})});const d=await r.json();addLog(d.status, d.success?'#00ff00':'#ff4444');}catch(e){addLog(`[-] Ошибка: ${e}`,'#ff4444');}}
        async function find(){const resDiv=document.getElementById('res');resDiv.innerHTML='<p class="text-muted">Ищу...</p>';try{const r=await fetch('/api/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:document.getElementById('sch').value,token:document.getElementById('tok').value})});const d=await r.json();if(!d.success){addLog(d.status,'#ff4444');resDiv.innerHTML=`<p class="text-danger">${d.status}</p>`;return;}let h='';d.tracks.forEach(t=>{h+=`<div class="card p-2 d-flex flex-row justify-content-between align-items-center"><div><b>${t.title}</b><br><small class="text-muted">${t.artists}</small></div><button class="btn btn-sm btn-success" onclick="dl('${t.id}','${t.title}','${t.artists}')">⬇️</button></div>`;});resDiv.innerHTML=h||'<p class="text-danger">Ничего не найдено. Проверьте лог сервера.</p>';}catch(e){addLog(`[-] Ошибка поиска: ${e}`,'#ff4444');}}
        async function dl(i,t,a){addLog(`[>] Скачиваю: ${a} - ${t}...`,'#ffb300');try{const r=await fetch('/api/download_single',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({track_id:i,title:t,artists:a,path:document.getElementById('pth').value,token:document.getElementById('tok').value})});const d=await r.json();addLog(d.status, d.status.includes('[+]')?'#00ff00':'#ffa500');}catch(e){addLog(`[-] Ошибка: ${e}`,'#ff4444');}}
    </script>
</body>
</html>
"""

def get_track_download_url(track_id, headers):
    try:
        res = requests.get(f"https://api.music.yandex.net/tracks/{track_id}/download-info", headers=headers, timeout=5).json()
        selected = res['result'][0]
        for info in res['result']:
            if info.get('codec') == 'mp3' and info.get('bitrate_in_kbps', 0) > selected.get('bitrate_in_kbps', 0): selected = info
        xml_res = requests.get(selected['downloadInfoUrl'], headers=headers, timeout=5).text
        host = re.search(r'<host>(.*?)</host>', xml_res).group(1)
        path = re.search(r'<path>(.*?)</path>', xml_res).group(1)
        ts = re.search(r'<ts>(.*?)</ts>', xml_res).group(1)
        s = re.search(r'<s>(.*?)</s\>', xml_res).group(1)
        sign = md5(("XGRw9fAFZ7G1uSgTRPpXbNiSjR8g600C" + path[1:] + s).encode('utf-8')).hexdigest()
        return f"https://{host}/get-mp3/{sign}/{ts}{path}"
    except: return None

def download_track_core(track_id, title, artists, save_path, headers):
    filename = f"{artists} - {title}.mp3"
    filename = re.sub(r'[\\/*?:"<>|]', "_", filename)
    full_path = os.path.join(save_path, filename)
    if os.path.exists(full_path): return f"[~] Уже есть: {filename}"
    url = get_track_download_url(track_id, headers)
    if url:
        try:
            os.makedirs(save_path, exist_ok=True)
            with open(full_path, "wb") as f: f.write(requests.get(url, timeout=10).content)
            return f"[+] Скачан: {filename}"
        except Exception as e: return f"[-] Ошибка записи: {e}"
    return f"[-] Яндекс отклонил выдачу файла для {title}"

@app.route('/')
def index(): return render_template_string(HTML_TEMPLATE)

@app.route('/api/search', methods=['POST'])
def search():
    data = request.json
    headers = {"Authorization": f"OAuth {data['token']}", "User-Agent": "Yandex-Music-API"}
    try:
        res = requests.get(f"https://api.music.yandex.net/search?text={data['query']}&type=track&page=0", headers=headers, timeout=5).json()
        out = []
        
        # Умный разбор новой структуры поиска Яндекса
        result_data = res.get('result', {})
        tracks_source = []
        if 'tracks' in result_data:
            tracks_source = result_data['tracks'].get('results', [])
        elif 'textPages' in result_data:
            # На случай если Яндекс отдал текстовые страницы результатов
            for page in result_data.get('textPages', []):
                for val in page.get('searchResult', {}).get('tracks', {}).get('results', []):
                    tracks_source.append(val)

        for t in tracks_source[:10]:
            artists = ", ".join([a['name'] for a in t.get('artists', [])])
            out.append({"id": t['id'], "title": t['title'], "artists": artists})
            
        return jsonify({"success": True, "tracks": out})
    except Exception as e:
        return jsonify({"success": False, "status": f"[!] Ошибка разбора: {e}"})

@app.route('/api/download_single', methods=['POST'])
def download_single():
    data = request.json
    headers = {"Authorization": f"OAuth {data['token']}", "User-Agent": "Yandex-Music-API"}
    return jsonify({"status": download_track_core(data['track_id'], data['title'], data['artists'], data['path'], headers)})

@app.route('/api/action', methods=['POST'])
def action():
    data = request.json
    headers = {"Authorization": f"OAuth {data['token']}", "User-Agent": "Yandex-Music-API"}
    save_path = data['path']
    try:
        if data['type'] == 'sync_likes':
            status_res = requests.get("https://api.music.yandex.net/account/status", headers=headers, timeout=5).json()
            uid = status_res['result']['account']['uid']
            
            res = requests.get(f"https://api.music.yandex.net/users/{uid}/likes/tracks", headers=headers, timeout=5).json()
            # Проверяем структуру лайков
            library = res.get('result', {})
            if 'library' in library: library = library['library']
            tracks = library.get('tracks', [])
            
            if not tracks:
                return jsonify({"success": True, "status": "[~] Треков в лайках не найдено. Попробуйте скачать по ссылке!"})
                
            dl, sk = 0, 0
            for item in tracks:
                # Яндекс может отдавать трек напрямую или внутри ключа 'track'
                t = item.get('track') if 'track' in item else item
                if t and (t.get('available') or 'id' in t):
                    title = t.get('title', 'Unknown Title')
                    artists = ", ".join([a['name'] for a in t.get('artists', [])]) if t.get('artists') else 'Unknown Artist'
                    res_str = download_track_core(t['id'], title, artists, save_path, headers)
                    if "[+]" in res_str: dl += 1
                    else: sk += 1
            return jsonify({"success": True, "status": f"[Успех] Добавлено новинок: {dl}, пропущено старых: {sk}"})
            
        elif data['type'] == 'by_url':
            url = data['url']
            if "track/" in url:
                track_id = url.split("track/")[-1].split("?")[0]
                req = requests.get(f"https://api.music.yandex.net/tracks/{track_id}", headers=headers, timeout=5).json()
                t = req['result'][0]
                artists = ", ".join([a['name'] for a in t['artists']]) if t.get('artists') else 'Unknown'
                status = download_track_core(t['id'], t['title'], artists, save_path, headers)
                return jsonify({"success": True, "status": status})
            elif "album/" in url:
                album_id = url.split("album/")[-1].split("?")[0]
                res = requests.get(f"https://api.music.yandex.net/albums/{album_id}/with-tracks", headers=headers, timeout=5).json()
                for vol in res['result'].get('volumes', []):
                    for t in vol:
                        artists = ", ".join([a['name'] for a in t['artists']]) if t.get('artists') else 'Unknown'
                        download_track_core(t['id'], t['title'], artists, save_path, headers)
                return jsonify({"success": True, "status": "[+] Весь альбом обработан!"})
    except Exception as e:
        return jsonify({"success": False, "status": f"[!] Ошибка операции: {e}"})
    return jsonify({"success": False, "status": "Неизвестная команда"})

def start_server():
    # The server binds only to the phone itself; it is not exposed to the local network.
    app.run(host="127.0.0.1", port=8550, debug=False, use_reloader=False)

if __name__ == "__main__":
    start_server()
