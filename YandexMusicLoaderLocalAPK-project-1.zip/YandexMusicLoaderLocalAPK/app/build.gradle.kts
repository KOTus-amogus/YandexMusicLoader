plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

android {
    namespace = "com.yandexloader.local"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.yandexloader.local"
        minSdk = 24
        // Legacy storage access is used so the existing Python path can write to Download.
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"

        python {
            pip {
                install("flask==3.0.3")
                install("requests==2.32.3")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
